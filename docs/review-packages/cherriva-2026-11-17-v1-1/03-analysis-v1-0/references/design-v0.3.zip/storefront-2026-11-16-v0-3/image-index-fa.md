# فهرست تصاویر نسخه ۰٫۳

وضعیت `in-review`؛ همه تصاویر خروجی آرت‌بورد محلی‌اند. تصاویر کامل با اندازه اصلی در همین پوشه قرار دارند.

## مقایسه‌ها و مرجع کنترل

- [سبد A/B/C](images/cart-directions-comparison.png).
- [پرداخت A/B/C](images/payment-directions-comparison.png).
- [کل مسیر خرید A](images/checkout-journey-balanced.png).
- [سبد و پرداخت موبایل A/B/C](images/checkout-mobile-comparison.png).
- [پنج صفحه خرید در سه جهت](images/checkout-all-directions.png).
- [حالت‌های حساس](images/checkout-states-overview.png).
- [دکمه قبل/بعد و حالت‌ها](images/purchase-control-states.png).
- [Home/PLP/PDP دسکتاپ](images/desktop-comparison.png).
- [Home/PLP/PDP موبایل](images/mobile-comparison.png).
- [صفحه اصلی](images/homepage-comparison.png).
- [صفحه اصلی موبایل](images/homepage-mobile-comparison.png).
- [صفحات اصلی کامل A](images/balanced-full-page-overview.png).

## A | BALANCED

| صفحه | دسکتاپ کامل | اولین نما | موبایل کامل | اولین نما |
| --- | --- | --- | --- | --- |
| خانه | [تصویر](images/balanced-home-desktop.png) | [تصویر](images/balanced-home-desktop-first-screen.png) | [تصویر](images/balanced-home-mobile.png) | [تصویر](images/balanced-home-mobile-first-screen.png) |
| فهرست | [تصویر](images/balanced-plp-desktop.png) | [تصویر](images/balanced-plp-desktop-first-screen.png) | [تصویر](images/balanced-plp-mobile.png) | [تصویر](images/balanced-plp-mobile-first-screen.png) |
| کالا | [تصویر](images/balanced-pdp-desktop.png) | [تصویر](images/balanced-pdp-desktop-first-screen.png) | [تصویر](images/balanced-pdp-mobile.png) | [تصویر](images/balanced-pdp-mobile-first-screen.png) |
| سبد | [تصویر](images/balanced-cart-desktop.png) | [تصویر](images/balanced-cart-desktop-first-screen.png) | [تصویر](images/balanced-cart-mobile.png) | [تصویر](images/balanced-cart-mobile-first-screen.png) |
| ورود | [تصویر](images/balanced-login-desktop.png) | [تصویر](images/balanced-login-desktop-first-screen.png) | [تصویر](images/balanced-login-mobile.png) | [تصویر](images/balanced-login-mobile-first-screen.png) |
| نشانی | [تصویر](images/balanced-address-desktop.png) | [تصویر](images/balanced-address-desktop-first-screen.png) | [تصویر](images/balanced-address-mobile.png) | [تصویر](images/balanced-address-mobile-first-screen.png) |
| ارسال | [تصویر](images/balanced-shipping-desktop.png) | [تصویر](images/balanced-shipping-desktop-first-screen.png) | [تصویر](images/balanced-shipping-mobile.png) | [تصویر](images/balanced-shipping-mobile-first-screen.png) |
| پرداخت | [تصویر](images/balanced-payment-desktop.png) | [تصویر](images/balanced-payment-desktop-first-screen.png) | [تصویر](images/balanced-payment-mobile.png) | [تصویر](images/balanced-payment-mobile-first-screen.png) |
| رسید موفق | [تصویر](images/balanced-result-desktop.png) | [تصویر](images/balanced-result-desktop-first-screen.png) | [تصویر](images/balanced-result-mobile.png) | [تصویر](images/balanced-result-mobile-first-screen.png) |

## B | SALES FOCUSED

| صفحه | دسکتاپ کامل | اولین نما | موبایل کامل | اولین نما |
| --- | --- | --- | --- | --- |
| خانه | [تصویر](images/sales-home-desktop.png) | [تصویر](images/sales-home-desktop-first-screen.png) | [تصویر](images/sales-home-mobile.png) | [تصویر](images/sales-home-mobile-first-screen.png) |
| فهرست | [تصویر](images/sales-plp-desktop.png) | [تصویر](images/sales-plp-desktop-first-screen.png) | [تصویر](images/sales-plp-mobile.png) | [تصویر](images/sales-plp-mobile-first-screen.png) |
| کالا | [تصویر](images/sales-pdp-desktop.png) | [تصویر](images/sales-pdp-desktop-first-screen.png) | [تصویر](images/sales-pdp-mobile.png) | [تصویر](images/sales-pdp-mobile-first-screen.png) |
| سبد | [تصویر](images/sales-cart-desktop.png) | [تصویر](images/sales-cart-desktop-first-screen.png) | [تصویر](images/sales-cart-mobile.png) | [تصویر](images/sales-cart-mobile-first-screen.png) |
| ورود | [تصویر](images/sales-login-desktop.png) | [تصویر](images/sales-login-desktop-first-screen.png) | [تصویر](images/sales-login-mobile.png) | [تصویر](images/sales-login-mobile-first-screen.png) |
| نشانی | [تصویر](images/sales-address-desktop.png) | [تصویر](images/sales-address-desktop-first-screen.png) | [تصویر](images/sales-address-mobile.png) | [تصویر](images/sales-address-mobile-first-screen.png) |
| ارسال | [تصویر](images/sales-shipping-desktop.png) | [تصویر](images/sales-shipping-desktop-first-screen.png) | [تصویر](images/sales-shipping-mobile.png) | [تصویر](images/sales-shipping-mobile-first-screen.png) |
| پرداخت | [تصویر](images/sales-payment-desktop.png) | [تصویر](images/sales-payment-desktop-first-screen.png) | [تصویر](images/sales-payment-mobile.png) | [تصویر](images/sales-payment-mobile-first-screen.png) |
| رسید موفق | [تصویر](images/sales-result-desktop.png) | [تصویر](images/sales-result-desktop-first-screen.png) | [تصویر](images/sales-result-mobile.png) | [تصویر](images/sales-result-mobile-first-screen.png) |

## C | PREMIUM

| صفحه | دسکتاپ کامل | اولین نما | موبایل کامل | اولین نما |
| --- | --- | --- | --- | --- |
| خانه | [تصویر](images/editorial-home-desktop.png) | [تصویر](images/editorial-home-desktop-first-screen.png) | [تصویر](images/editorial-home-mobile.png) | [تصویر](images/editorial-home-mobile-first-screen.png) |
| فهرست | [تصویر](images/editorial-plp-desktop.png) | [تصویر](images/editorial-plp-desktop-first-screen.png) | [تصویر](images/editorial-plp-mobile.png) | [تصویر](images/editorial-plp-mobile-first-screen.png) |
| کالا | [تصویر](images/editorial-pdp-desktop.png) | [تصویر](images/editorial-pdp-desktop-first-screen.png) | [تصویر](images/editorial-pdp-mobile.png) | [تصویر](images/editorial-pdp-mobile-first-screen.png) |
| سبد | [تصویر](images/editorial-cart-desktop.png) | [تصویر](images/editorial-cart-desktop-first-screen.png) | [تصویر](images/editorial-cart-mobile.png) | [تصویر](images/editorial-cart-mobile-first-screen.png) |
| ورود | [تصویر](images/editorial-login-desktop.png) | [تصویر](images/editorial-login-desktop-first-screen.png) | [تصویر](images/editorial-login-mobile.png) | [تصویر](images/editorial-login-mobile-first-screen.png) |
| نشانی | [تصویر](images/editorial-address-desktop.png) | [تصویر](images/editorial-address-desktop-first-screen.png) | [تصویر](images/editorial-address-mobile.png) | [تصویر](images/editorial-address-mobile-first-screen.png) |
| ارسال | [تصویر](images/editorial-shipping-desktop.png) | [تصویر](images/editorial-shipping-desktop-first-screen.png) | [تصویر](images/editorial-shipping-mobile.png) | [تصویر](images/editorial-shipping-mobile-first-screen.png) |
| پرداخت | [تصویر](images/editorial-payment-desktop.png) | [تصویر](images/editorial-payment-desktop-first-screen.png) | [تصویر](images/editorial-payment-mobile.png) | [تصویر](images/editorial-payment-mobile-first-screen.png) |
| رسید موفق | [تصویر](images/editorial-result-desktop.png) | [تصویر](images/editorial-result-desktop-first-screen.png) | [تصویر](images/editorial-result-mobile.png) | [تصویر](images/editorial-result-mobile-first-screen.png) |

## حالت‌ها و نمونه طلا

نام انگلیسی فایل، صفحه و حالت را مشخص می‌کند. `added` پس از افزودن، `changed` تغییر قیمت، `unavailable` ناموجودی، `empty` خالی، `otp/invalid` کد ورود/نادرست، `new-address` فرم نشانی، `wallet/credit/expired` موجودی کافی/اعتباری/انقضا و `pending/failed/topup` نامشخص/ناموفق/شارژ بدون سفارش است.

| تصویر حالت کامل | اولین نما |
| --- | --- |
| [balanced-address-new-address-desktop](images/balanced-address-new-address-desktop.png) | [تصویر](images/balanced-address-new-address-desktop-first-screen.png) |
| [balanced-address-new-address-mobile](images/balanced-address-new-address-mobile.png) | [تصویر](images/balanced-address-new-address-mobile-first-screen.png) |
| [balanced-cart-changed-desktop](images/balanced-cart-changed-desktop.png) | [تصویر](images/balanced-cart-changed-desktop-first-screen.png) |
| [balanced-cart-changed-mobile](images/balanced-cart-changed-mobile.png) | [تصویر](images/balanced-cart-changed-mobile-first-screen.png) |
| [balanced-cart-empty-desktop](images/balanced-cart-empty-desktop.png) | [تصویر](images/balanced-cart-empty-desktop-first-screen.png) |
| [balanced-cart-empty-mobile](images/balanced-cart-empty-mobile.png) | [تصویر](images/balanced-cart-empty-mobile-first-screen.png) |
| [balanced-cart-unavailable-desktop](images/balanced-cart-unavailable-desktop.png) | [تصویر](images/balanced-cart-unavailable-desktop-first-screen.png) |
| [balanced-cart-unavailable-mobile](images/balanced-cart-unavailable-mobile.png) | [تصویر](images/balanced-cart-unavailable-mobile-first-screen.png) |
| [balanced-gold-pdp-desktop](images/balanced-gold-pdp-desktop.png) | [تصویر](images/balanced-gold-pdp-desktop-first-screen.png) |
| [balanced-gold-pdp-mobile](images/balanced-gold-pdp-mobile.png) | [تصویر](images/balanced-gold-pdp-mobile-first-screen.png) |
| [balanced-gold-plp-desktop](images/balanced-gold-plp-desktop.png) | [تصویر](images/balanced-gold-plp-desktop-first-screen.png) |
| [balanced-gold-plp-mobile](images/balanced-gold-plp-mobile.png) | [تصویر](images/balanced-gold-plp-mobile-first-screen.png) |
| [balanced-login-invalid-desktop](images/balanced-login-invalid-desktop.png) | [تصویر](images/balanced-login-invalid-desktop-first-screen.png) |
| [balanced-login-invalid-mobile](images/balanced-login-invalid-mobile.png) | [تصویر](images/balanced-login-invalid-mobile-first-screen.png) |
| [balanced-login-otp-desktop](images/balanced-login-otp-desktop.png) | [تصویر](images/balanced-login-otp-desktop-first-screen.png) |
| [balanced-login-otp-mobile](images/balanced-login-otp-mobile.png) | [تصویر](images/balanced-login-otp-mobile-first-screen.png) |
| [balanced-payment-credit-desktop](images/balanced-payment-credit-desktop.png) | [تصویر](images/balanced-payment-credit-desktop-first-screen.png) |
| [balanced-payment-credit-mobile](images/balanced-payment-credit-mobile.png) | [تصویر](images/balanced-payment-credit-mobile-first-screen.png) |
| [balanced-payment-expired-desktop](images/balanced-payment-expired-desktop.png) | [تصویر](images/balanced-payment-expired-desktop-first-screen.png) |
| [balanced-payment-expired-mobile](images/balanced-payment-expired-mobile.png) | [تصویر](images/balanced-payment-expired-mobile-first-screen.png) |
| [balanced-payment-wallet-desktop](images/balanced-payment-wallet-desktop.png) | [تصویر](images/balanced-payment-wallet-desktop-first-screen.png) |
| [balanced-payment-wallet-mobile](images/balanced-payment-wallet-mobile.png) | [تصویر](images/balanced-payment-wallet-mobile-first-screen.png) |
| [balanced-pdp-added-desktop](images/balanced-pdp-added-desktop.png) | [تصویر](images/balanced-pdp-added-desktop-first-screen.png) |
| [balanced-pdp-added-mobile](images/balanced-pdp-added-mobile.png) | [تصویر](images/balanced-pdp-added-mobile-first-screen.png) |
| [balanced-profile-state](images/balanced-profile-state.png) | — |
| [balanced-result-failed-desktop](images/balanced-result-failed-desktop.png) | [تصویر](images/balanced-result-failed-desktop-first-screen.png) |
| [balanced-result-failed-mobile](images/balanced-result-failed-mobile.png) | [تصویر](images/balanced-result-failed-mobile-first-screen.png) |
| [balanced-result-pending-desktop](images/balanced-result-pending-desktop.png) | [تصویر](images/balanced-result-pending-desktop-first-screen.png) |
| [balanced-result-pending-mobile](images/balanced-result-pending-mobile.png) | [تصویر](images/balanced-result-pending-mobile-first-screen.png) |
| [balanced-result-topup-desktop](images/balanced-result-topup-desktop.png) | [تصویر](images/balanced-result-topup-desktop-first-screen.png) |
| [balanced-result-topup-mobile](images/balanced-result-topup-mobile.png) | [تصویر](images/balanced-result-topup-mobile-first-screen.png) |
| [balanced-search-state](images/balanced-search-state.png) | — |
| [editorial-pdp-added-desktop](images/editorial-pdp-added-desktop.png) | [تصویر](images/editorial-pdp-added-desktop-first-screen.png) |
| [editorial-pdp-added-mobile](images/editorial-pdp-added-mobile.png) | [تصویر](images/editorial-pdp-added-mobile-first-screen.png) |
| [sales-pdp-added-desktop](images/sales-pdp-added-desktop.png) | [تصویر](images/sales-pdp-added-desktop-first-screen.png) |
| [sales-pdp-added-mobile](images/sales-pdp-added-mobile.png) | [تصویر](images/sales-pdp-added-mobile-first-screen.png) |
